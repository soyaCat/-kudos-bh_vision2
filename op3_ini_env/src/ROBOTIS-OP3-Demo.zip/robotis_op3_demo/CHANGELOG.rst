^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robotis_op3_demo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2018-04-19)
------------------
* first release for ROS Kinetic
* added launch files in order to move the camera setting to op3_camera_setting package
* added missing package in find_package()
* updated CMakeLists.txt and package.xml of op3_bringup
* changed rviz config file
* refacoring to release
* split repositoryfrom ROBOTIS-OP3
* Contributors: Kayman, Zerom, Yoshimaru Tanaka, Pyo
