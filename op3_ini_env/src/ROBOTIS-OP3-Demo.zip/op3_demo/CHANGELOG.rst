^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_demo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2018-04-19)
------------------
* first release for ROS Kinetic
* added launch files in order to move the camera setting to op3_camera_setting package
* added missing package in find_package()
* refacoring to release
* split repositoryfrom ROBOTIS-OP3
* Contributors: Kayman, Zerom, Yoshimaru Tanaka, Pyo
