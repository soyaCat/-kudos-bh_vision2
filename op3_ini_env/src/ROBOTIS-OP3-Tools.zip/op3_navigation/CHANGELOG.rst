^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_navigation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.2 (2018-04-20)
------------------
* none

0.2.1 (2018-04-19)
------------------
* tested for dependencies of ncurses
* tested for dependencies of footstep_planner
* Contributors: Pyo

0.2.0 (2018-03-30)
------------------
* modified CMakeLists.txt and package.xml for dependencies
* modified package.xml format to v2
* split repository from ROBOTIS-OP3
* Contributors: Kayman, Pyo
