^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_action_editor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
-----------
* test for dependencies of ncurses
* test for dependencies of ncurses
* test for dependencies of ncurses
* test for dependencies of ncurses
* test for dependencies of ncurses
* added ncurses
* added ncurses++
* added ncurses++
* added libncurses-dev
* modified CMakeLists.txt and package.xml for dependencies
* refactoring to release
* refactoring to release
* changed package.xml format to v2
* added test code for web setting tool
* Changed license from BSD to Apache 2.0
* fixed typo.
  added configuration for direct control
* fixed minor bug and function about offset.yaml
* modified the help description of op3_aciton_editor
* cleaned up the code.
* Repository split from ROBOTIS-OP3
* Contributors: Kayman, Pyo
