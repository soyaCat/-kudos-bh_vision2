^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robotis_op3_tools
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.2 (2018-04-20)
------------------
* modified package.xml for dependency (yaml-cpp)
* Contributors: Pyo

0.2.1 (2018-04-19)
------------------
* tested for dependencies of ncurses
* tested for dependencies of footstep_planner
* Contributors: Pyo

0.2.0 (2018-03-30)
------------------
* added libncurses-dev
* added test code for web setting tool
* added configuration for direct control
* modified CMakeLists.txt and package.xml for dependencies
* modified the help description of op3_aciton_editor
* modified package.xml format to v2
* fixed minor bug and function about offset.yaml
* split repository from ROBOTIS-OP3
* refactoring to release
* Contributors: Kayman, Pyo
