^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robotis_controller_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.4 (2018-03-22)
------------------
* added service to set module
* modified documents
* Contributors: Kayman, Pyo

0.1.3 (2018-03-20)
------------------
* refactoring to release
* Contributors: Pyo

0.1.2 (2018-03-15)
------------------
* changed LICENSE
* refactoring for release
* Contributors: Pyo

0.1.1 (2016-11-23)
------------------
* added WriteControlTable.msg
* Contributors: SCH, Jay Song, Zerom

0.1.0 (2016-08-12)
------------------
* first public release for Kinetic
* modified the package information
* added robotis_controller_msgs
* Contributors: Zerom, Pyo
