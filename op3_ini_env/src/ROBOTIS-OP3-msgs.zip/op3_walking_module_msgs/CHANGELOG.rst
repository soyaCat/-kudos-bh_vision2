^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package op3_walking_module_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2018-03-21)
------------------
* changed package.xml format to v2
* Contributors: Pyo

0.1.0 (2017-10-27)
------------------
* added msg package for ROBOTIS OP3
* Contributors: Kayman, Yoshimaru Tanaka
