^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robotis_op3_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2018-03-21)
------------------
* added online walking module msgs
* changed package.xml format to v2
* Contributors: Pyo

0.1.0 (2017-10-27)
------------------
* added msg package for ROBOTIS OP3
* Contributors: Kayman
