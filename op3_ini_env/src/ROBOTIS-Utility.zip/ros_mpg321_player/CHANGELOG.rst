^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros_mpg321_player
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.3 (2018-03-21)
------------------
* fixed movement_done msg publish bug
* changed package format to v2 and LICENSE to Apache 2.0
* Contributors: Zerom, Pyo

0.1.2 (2017-04-24)
------------------
* added movement done msg
* Contributors: Jay Song

0.1.1 (2016-09-23)
------------------
* modified install rule
* Contributors: Zerom, Pyo

0.1.0 (2016-08-17)
------------------
* added ros_mpg321_player pkg
* made the meta-package for rosbotis utility
* modified ros_mpg321_player, edit package.xml, add stop playing
* Contributors: Zerom, Jay Song, Pyo
