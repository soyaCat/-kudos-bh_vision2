^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros_madplay_player
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.3 (2018-03-21)
------------------
* changed package format to v2 and LICENSE to Apache 2.0
* fixed movement_done msg publish bug
* Contributors: Zerom, Pyo

0.1.2 (2017-04-24)
------------------
* modified ros_madplay_player pkg
* Contributors: Jay Song

0.1.1 (2017-02-03)
------------------
* added ros_madplay_player pkg
* Contributors: Zerom, Jay Song, Pyo

0.1.0 (2016-08-17)
------------------
* made the meta-package for rosbotis utility
* Contributors: Zerom, Pyo